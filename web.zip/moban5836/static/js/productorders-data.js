
$(document).ready(function(){
	"use strict";
    $('#myTable').DataTable();
});